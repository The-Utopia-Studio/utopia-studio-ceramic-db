# Articulated Studio astrolabe

This is a separately reconstructed animation variant. It is not a mechanically segmented version of the supplied image-to-3D GLB. That original fused mesh is preserved unchanged in the main asset library as `assets/studio-astrolabe.glb`.

## Build

Run `npm ci`, then `npm run build`. Include `dist/hero-3d.js` as a module script. Three.js and its studio environment are bundled locally; no remote runtime or model request is needed. Retain the included Three.js license when distributing the bundle.

## Integration

Use the `hero.html` fragment and `hero.css` with the current Utopia Studio semantic theme and its typography, shell, button, eyebrow, and supporting-text styles. The scene expects `.hero` for scroll progress and `[data-hero-model]` for its canvas. Keep the fallback SVG and real HTML content. The hero owns its sticky scroll section; do not fix the document or intercept scrolling.

## Editable parts

`src/hero-3d.js` builds five independent geometry groups: case/backplate, engraved tympan, openwork rete, alidade pointer, and axle cap. The original image-to-3D asset has no separable mechanical parts; the reconstruction makes these groups explicit rather than cutting arbitrary triangles. Dial graphics are generated locally as editable Canvas textures. Brass rendering materials are artwork colors; page surfaces use semantic theme tokens.

The `pose()` function defines the choreography. From scroll progress 0.07–0.43 the layers spread along their depth axis; from 0.65–0.98 they reassemble. The rete and pointer have independent slow rotation while visible. Reverse scrolling reverses the separation. The model is a visual interpretation, not a scientific simulation of a historical instrument.

## Accessibility and performance

The canvas is decorative and hidden from assistive technology. Text and the application CTA remain real HTML. Reduced-motion preference freezes the composed instrument and removes the prolonged sticky section. An offscreen scene or hidden tab stops animation frames. Pixel ratio is capped at 1.5. If WebGL is unavailable, the static Studio SVG remains visible and the hero uses normal section height.

Browser-readable diagnostics on the host: `data-model-state`, `data-motion`, `data-exploded`, and `data-scroll-progress`. These are not product UI.
