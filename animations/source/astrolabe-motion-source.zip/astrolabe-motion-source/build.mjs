import { build } from 'esbuild';
await build({ entryPoints: ['src/hero-3d.js'], bundle: true, format: 'esm', minify: true, legalComments: 'linked', outfile: 'dist/hero-3d.js' });
