/**
 * Articulated Studio astrolabe — reconstructed animation variant.
 * The supplied image-to-3D GLB is a fused mesh, preserved unchanged at
 * assets/studio-astrolabe.glb. This scene deliberately builds separate
 * body, tympan, rete, alidade and axle groups; it does not split that mesh.
 */
import { ACESFilmicToneMapping, AmbientLight, BoxGeometry, CanvasTexture, CircleGeometry, CylinderGeometry, DirectionalLight, DoubleSide, ExtrudeGeometry, Group, HemisphereLight, Mesh, MeshStandardMaterial, PerspectiveCamera, PMREMGenerator, Scene, Shape, SRGBColorSpace, TorusGeometry, WebGLRenderer } from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const host = document.querySelector('[data-hero-model]');
const section = document.querySelector('.hero');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const clamp = value => Math.max(0, Math.min(1, value));
const smooth = (a,b,t) => { const x=clamp((t-a)/(b-a)); return x*x*(3-2*x); };

function dialTexture(projected=false) {
  const canvas=document.createElement('canvas'); canvas.width=canvas.height=1024;
  const c=canvas.getContext('2d'); c.translate(512,512);
  if(!projected) { c.fillStyle='#342c23'; c.beginPath();c.arc(0,0,510,0,Math.PI*2);c.fill(); }
  c.save();c.beginPath();c.arc(0,0,490,0,Math.PI*2);c.clip();
  c.strokeStyle=projected?'#9f8055':'#7f6a4b'; c.lineWidth=projected?1.8:1.2;
  const circle=(x,y,r)=>{c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.stroke();};
  if(projected) {
    [65,125,205,300,430,600,840].forEach(r=>circle(0,150,r));
    [-600,-320,-160,0,160,320,600].forEach(x=>circle(x,-270,Math.hypot(x,490)));
    c.beginPath();c.moveTo(-490,0);c.lineTo(490,0);c.moveTo(0,-490);c.lineTo(0,490);c.stroke();
    [100,200,300,400,482].forEach(r=>circle(0,0,r));
  } else {
    [388,407,458,482,495].forEach(r=>circle(0,0,r));
    for(let i=0;i<180;i++) {
      const a=i*Math.PI/90, inner=i%5===0?412:432;
      c.lineWidth=i%5===0?2:1;
      c.beginPath();c.moveTo(Math.sin(a)*inner,Math.cos(a)*inner);c.lineTo(Math.sin(a)*454,Math.cos(a)*454);c.stroke();
    }
    c.fillStyle='#c0a373';c.font='22px Georgia';c.textAlign='center';c.textBaseline='middle';
    for(let i=0;i<24;i++){c.save();c.rotate(i*Math.PI/12);c.fillText(String(i*15),0,-472);c.restore();}
    c.strokeStyle='#64563f';
    for(let i=0;i<8;i++){c.save();c.rotate(i*Math.PI/4);c.beginPath();c.moveTo(0,-372);c.lineTo(0,372);c.stroke();c.restore();}
    [120,240,360].forEach(r=>circle(0,0,r));
    for(let i=0;i<48;i++){const a=i*2.39996,r=75+Math.sqrt(i/48)*290;c.fillStyle=i%5?'#756246':'#bc9c68';c.beginPath();c.arc(Math.cos(a)*r,Math.sin(a)*r,i%5?1.4:2.5,0,Math.PI*2);c.fill();}
  }
  c.restore(); const texture=new CanvasTexture(canvas);texture.colorSpace=SRGBColorSpace; return texture;
}

function buildAstrolabe() {
  const brass=new MeshStandardMaterial({color:0x9c7746,metalness:.87,roughness:.3});
  const satin=new MeshStandardMaterial({color:0x725c3c,metalness:.86,roughness:.43});
  const edge=new MeshStandardMaterial({color:0xd0ac70,metalness:.9,roughness:.27});
  const dark=new MeshStandardMaterial({color:0x28231e,metalness:.8,roughness:.4});
  const root=new Group(),body=new Group(),tympan=new Group(),rete=new Group(),alidade=new Group(),axle=new Group();
  root.add(body,tympan,rete,alidade,axle);
  const ring=(group,r,t,z=0,material=brass,x=0,y=0)=>{const m=new Mesh(new TorusGeometry(r,t,8,128),material);m.position.set(x,y,z);group.add(m);return m;};
  const disk=(group,r,thickness,z,material)=>{const m=new Mesh(new CylinderGeometry(r,r,thickness,128),material);m.rotation.x=Math.PI/2;m.position.z=z;group.add(m);return m;};
  disk(body,1.03,.085,-.05,dark);
  const face=new Mesh(new CircleGeometry(1.02,128),new MeshStandardMaterial({map:dialTexture(),metalness:.7,roughness:.53}));face.position.z=.001;body.add(face);
  ring(body,1.055,.029,-.008,edge);ring(body,1.012,.012,.025,satin);ring(body,.835,.008,.025,edge);
  ring(body,1.06,.015,-.085,satin);
  const shoulder=new Mesh(new BoxGeometry(.13,.16,.08),brass);shoulder.position.set(0,1.075,-.035);body.add(shoulder);
  ring(body,.105,.019,-.035,brass,0,1.225);ring(body,.035,.012,-.035,edge,0,1.101);
  // A separate engraved climate plate, followed by the openwork star map.
  const projection=new Mesh(new CircleGeometry(.82,128),new MeshStandardMaterial({map:dialTexture(true),transparent:true,metalness:.62,roughness:.52,side:DoubleSide,depthWrite:false}));
  tympan.add(projection);ring(tympan,.82,.011,0,satin);tympan.position.z=.07;
  ring(rete,.79,.013,0,brass);ring(rete,.59,.018,.005,edge,0,-.16);ring(rete,.21,.012,.006,brass);
  const beam=(group,length,width,angle,z=0)=>{const m=new Mesh(new BoxGeometry(width,length,.018),brass);m.rotation.z=angle;m.position.z=z;group.add(m);return m;};
  beam(rete,1.57,.018,Math.PI/2);beam(rete,1.57,.014,Math.PI/6);beam(rete,1.57,.014,-Math.PI/6);
  for(let i=0;i<9;i++){
    const a=i*2*Math.PI/9+.16,r=.69;
    const star=new Shape();star.moveTo(0,.07);star.lineTo(.019,-.022);star.lineTo(0,-.008);star.lineTo(-.019,-.022);star.closePath();
    const m=new Mesh(new ExtrudeGeometry(star,{depth:.014,bevelEnabled:false}),edge);m.position.set(Math.cos(a)*r,Math.sin(a)*r,.012);m.rotation.z=a-Math.PI/2;rete.add(m);
  }
  rete.position.z=.115;
  const pointer=new Shape();pointer.moveTo(0,1.01);pointer.lineTo(.044,.88);pointer.lineTo(.026,.18);pointer.lineTo(.073,.07);pointer.lineTo(.073,-.07);pointer.lineTo(.026,-.18);pointer.lineTo(.044,-.88);pointer.lineTo(0,-1.01);pointer.lineTo(-.044,-.88);pointer.lineTo(-.026,-.18);pointer.lineTo(-.073,-.07);pointer.lineTo(-.073,.07);pointer.lineTo(-.026,.18);pointer.lineTo(-.044,.88);pointer.closePath();
  const ruler=new Mesh(new ExtrudeGeometry(pointer,{depth:.025,bevelEnabled:true,bevelSize:.006,bevelThickness:.004,bevelSegments:1}),brass);alidade.add(ruler);alidade.position.z=.17;
  const groove=new Mesh(new BoxGeometry(.004,1.7,.005),dark);groove.position.set(0,0,.031);alidade.add(groove);
  for(const y of [-.76,.76]){const sight=new Mesh(new BoxGeometry(.085,.027,.085),edge);sight.position.set(0,y,.05);alidade.add(sight);}
  disk(axle,.095,.045,0,edge);ring(axle,.067,.008,.028,satin);disk(axle,.029,.026,.031,dark);axle.position.z=.235;
  return {root,body,tympan,rete,alidade,axle};
}

async function mount() {
 if(!host||!section)return;
 let renderer;
 try{renderer=new WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});}catch{host.dataset.modelState='fallback';return;}
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.outputColorSpace=SRGBColorSpace;renderer.toneMapping=ACESFilmicToneMapping;renderer.toneMappingExposure=.86;renderer.setClearColor(0,0);
 const canvas=renderer.domElement;canvas.className='hero-model-canvas';canvas.setAttribute('aria-hidden','true');host.appendChild(canvas);
 const scene=new Scene(),camera=new PerspectiveCamera(34,1,.01,30);camera.position.set(0,.08,5.8);camera.lookAt(0,.08,0);
 const room=new RoomEnvironment(),pmrem=new PMREMGenerator(renderer),environment=pmrem.fromScene(room,.07);scene.environment=environment.texture;scene.environmentIntensity=.65;room.dispose();pmrem.dispose();
 const key=new DirectionalLight(0xffe6c4,3.2);key.position.set(-3,4,5);
 const rim=new DirectionalLight(0xd8e3ff,2.3);rim.position.set(4,1,-2);
 scene.add(key,rim,new HemisphereLight(0xfff3de,0x1e191b,.45),new AmbientLight(0xffffff,.12));
 const parts=buildAstrolabe();scene.add(parts.root);
 let loaded=false,inView=true,raf=0,last=0,elapsed=0,progress=0,target=0;
 const draw=()=>renderer.render(scene,camera);
 const canRun=()=>loaded&&inView&&!document.hidden&&!reduced.matches;
 function readProgress(){const rect=section.getBoundingClientRect();target=reduced.matches?0:clamp(-rect.top/Math.max(1,rect.height-innerHeight));}
 function pose(){
  const spread=smooth(.07,.43,progress)*(1-smooth(.65,.98,progress));
  parts.root.rotation.set(-.10+spread*.18,-.20-spread*.72,.035-spread*.07);
  parts.root.position.set(-spread*.08,-.06,-spread*.22);
  camera.position.z=(host.clientWidth<500?5.3:4.9)+spread*.5;
  parts.body.position.z=-spread*.68;
  parts.tympan.position.z=.07-spread*.16;
  parts.rete.position.z=.115+spread*.45;
  parts.alidade.position.z=.17+spread*1.08;
  parts.axle.position.z=.235+spread*1.51;
  parts.rete.rotation.z=reduced.matches?.16:.16+elapsed*.055+spread*.28;
  parts.alidade.rotation.z=reduced.matches?-.63:-.63-elapsed*.085+spread*.58;
  host.dataset.exploded=spread>.5?'true':'false';
  host.dataset.scrollProgress=progress.toFixed(3);
 }
 function tick(time){raf=0;if(!canRun()){last=0;return;}const dt=last?Math.min((time-last)/1000,.05):0;last=time;elapsed+=dt;progress+=(target-progress)*(1-Math.exp(-dt*10));pose();draw();raf=requestAnimationFrame(tick);}
 function playback(){cancelAnimationFrame(raf);raf=0;last=0;if(reduced.matches){progress=target=0;elapsed=0;}readProgress();pose();if(loaded&&inView&&!document.hidden)draw();if(canRun())raf=requestAnimationFrame(tick);host.dataset.motion=reduced.matches?'reduced':canRun()?'running':'paused';}
 const resize=new ResizeObserver(()=>{const{width,height}=host.getBoundingClientRect();if(!width||!height)return;renderer.setSize(width,height,false);camera.aspect=width/height;camera.position.z=width<500?6.3:5.8;camera.updateProjectionMatrix();readProgress();if(loaded){pose();draw();}});resize.observe(host);
 const visibility=new IntersectionObserver(entries=>{inView=entries[0].isIntersecting;playback();},{threshold:.01});visibility.observe(host);
 addEventListener('scroll',readProgress,{passive:true});addEventListener('resize',readProgress,{passive:true});document.addEventListener('visibilitychange',playback);reduced.addEventListener('change',playback);
 canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();loaded=false;playback();host.dataset.modelState='fallback';});
 canvas.addEventListener('webglcontextrestored',()=>{loaded=true;host.dataset.modelState='ready';playback();});
 try{await renderer.compileAsync(scene,camera);loaded=true;host.dataset.modelState='ready';playback();}catch(error){host.dataset.modelState='fallback';canvas.remove();resize.disconnect();visibility.disconnect();renderer.dispose();console.warn('Astrolabe scene unavailable; showing the Studio illustration.',error);}
}
mount();
